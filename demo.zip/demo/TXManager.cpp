#include "TXManager.h"
#include <future>

int TransactionManager::GetReadLock(){
    return pthread_rwlock_rdlock(&rwLock);
}

int TransactionManager::GetWriteLock(){
    return pthread_rwlock_wrlock(&rwLock);
}

int TransactionManager::Unlock(){
    return pthread_rwlock_unlock(&rwLock);
}

bool operator == (const IndexAOF &t1, const IndexAOF &t2){
    return (t1.delta==t2.delta)&&(t1.op==t2.op)&&(t1.rawKey==t2.rawKey)&&(t1.version==t2.version);
}

std::vector<std::string> split(const std::string &str, const std::string &pattern){
    std::vector<std::string> res;
    if(str=="") return res;
    std::string strs = str+pattern;
    size_t pos = strs.find(pattern);
    while(pos!=strs.npos){
        std::string tp = strs.substr(0,pos);
        res.emplace_back(tp);
        strs = strs.substr(pos+1, strs.size());
        pos = strs.find(pattern);
    }
    return res;
}

int64_t TransactionManager::GetMinTX(){
    if(this->ActiveTX.size()==0) return 0;
    return *this->ActiveTX.begin();
}

int64_t TransactionManager::GetMaxTX(){
    if(this->ActiveTX.size()==0) return 0;
    return *this->ActiveTX.rbegin();
}


bool TransactionManager::Register(int64_t TID){
    using defer=std::shared_ptr<void>;
    GetReadLock();
    defer(nullptr,[&](...){
        Unlock();
    });
    if (TID<=0) return false;
    this->ActiveTX.insert(TID);
    auto TX = new Transaction(TID);
    this->TXs.emplace(TID,TX);
    return true;
}

// 事务提交时，将所有读写记录写成AOF落盘
bool TransactionManager::Commit(int64_t TID){
    using defer=std::shared_ptr<void>;
    GetReadLock();
    defer(nullptr,[&](...){
        Unlock();
    });
    if(this->TXs.find(TID)==TXs.end()){
        std::cout<<"Cannot find the txn "<<TID<<"\n";
        return false;
    }
    auto tx = this->TXs[TID];
    std::vector<IndexAOF> buf;
    // 读记录AOF
    for(auto x: tx->ReadSet){
        auto key = x.first;
        for(auto tp:x.second){
            if(tp.deltaTs==0) continue;
            IndexAOF t{'m',key,tp.version,tp.deltaTs};
            buf.emplace_back(t);
        }
    }
    auto indexMap = &this->GlobalMap.IndexMap;
    // 写记录AOF
    for(auto x: tx->WriteSet){
        auto key = x.first;
        for(auto item:x.second){
            if(item.operation=='a'){
                IndexAOF t{'a',key,item.version};
                buf.emplace_back(t);
            }else if(item.operation=='d'){
                IndexAOF t{'d',key,item.version};
                buf.emplace_back(t);
            }
        }
        auto it = indexMap->find(key);
        if(it==indexMap->end()){
            std::cout<<"Cannot find key "<<x.first<<"\n";
            return false;
        }
        // 释放该事务持有的所有写锁
        for(auto iter=it->second.begin(); iter!=it->second.end(); iter++){
            if(iter->WriteLock.load()==TID) {
                iter->WriteLock.store(0);
            }
        }
    }
    // undo write sets 操作提交
    for(auto x: tx->UndoWriteSet){
        auto rawKey = x.first;
        std::list<IndexVersion> newVesionList;
        IndexAOF t{'d',rawKey,0};
        buf.emplace_back(t);

        // 写入新版本的AOF
        if(x.second.operation=='a'){
            newVesionList.emplace_back(IndexVersion{0,x.second.version,x.second.version});
            IndexAOF tt{'a',rawKey,x.second.version};
            buf.emplace_back(tt);
        }

        // 删除数据库中的原始版本链上版本
        for(auto iter=indexMap->find(rawKey); iter!=indexMap->end();){
            auto oldVersionList = iter->second;
            if(oldVersionList.size()==0) break;
            std::vector<std::string> deleteKeys;
            for(auto l:oldVersionList){
                if(l.BeginTs>0) deleteKeys.emplace_back(rawKey+std::to_string(l.BeginTs));
            }
            rocksdbapi.MultiDelete(deleteKeys);
        }

        // 更换版本链
        (*indexMap)[rawKey] = newVesionList;        
    }
    bool success = WriteIndexAOF(buf);
    if(!success) return false;

    // 对Insert和Delete Edges的AOF
    std::vector<VEAOF> vv;
    if(tx->InsertEdges.count()>0||tx->DeleteEdges.count()>0){
        auto addEdges = (tx->InsertEdges&(~tx->DeleteEdges)).to_string();
        auto removeEdges = (tx->DeleteEdges&(~tx->InsertEdges)).to_string();
        reverse(addEdges.begin(),addEdges.end());
        reverse(removeEdges.begin(),removeEdges.end());
        auto bitsetSize = tx->EdgeIndexes.size();
        std::unordered_map<std::string,std::vector<Edge> > inAddMap;
        std::unordered_map<std::string,std::vector<Edge> > outAddMap;
        std::unordered_map<std::string,std::vector<Edge> > inDelMap;
        std::unordered_map<std::string,std::vector<Edge> > outDelMap;
        for(auto i=0;i<bitsetSize;i++){
            auto edge = tx->EdgeIndexes[i];
            auto srcID = edge.GetSrcID();
            auto dstID = edge.GetDstID();
            if(addEdges[i]=='1'){
                std::vector<Edge> t;
                t.emplace_back(edge);
                if(outAddMap.count(srcID)==0){
                    outAddMap.emplace(srcID,t);
                }else{
                    outAddMap[srcID].emplace_back(edge);
                }
                if(inAddMap.count(dstID)==0){
                    inAddMap.emplace(dstID,t);
                }else{
                    inAddMap[dstID].emplace_back(edge);
                }
            }
            else if(removeEdges[i]=='1'){
                std::vector<Edge> t;
                t.emplace_back(edge);
                if(outDelMap.count(srcID)==0){
                    outDelMap.emplace(srcID,t);
                }else{
                    outDelMap[srcID].emplace_back(edge);
                }
                if(inDelMap.count(dstID)==0){
                    inDelMap.emplace(dstID,t);
                }else{
                    inDelMap[dstID].emplace_back(edge);
                }
            }
        }
        std::set<std::string> inVertexKeys;
        std::set<std::string> outVertexKeys;
        for(auto it:inAddMap){
            VEAOF t{'1',it.first,TID};
            t.insertEdges = it.second;
            vv.emplace_back(t);
            inVertexKeys.emplace(it.first);
        }
        for(auto it:outAddMap){
            VEAOF t{'0',it.first,TID};
            t.insertEdges = it.second;
            vv.emplace_back(t);
            outVertexKeys.emplace(it.first);
        }
        for(auto it:inDelMap){
            VEAOF t{'1',it.first,TID};
            t.deleteEdges = it.second;
            vv.emplace_back(t);
            inVertexKeys.emplace(it.first);
        }
        for(auto it:outDelMap){
            VEAOF t{'0',it.first,TID};
            t.deleteEdges = it.second;
            vv.emplace_back(t);
            outVertexKeys.emplace(it.first);
        }
        // 释放VE Map上的写锁
        auto outMap = &GlobalMap.OutEdges;
        auto inMap = &GlobalMap.InEdges;
        for(auto vertex:inVertexKeys){
            auto veVersionList = &(*inMap)[vertex];
            for(auto it=veVersionList->begin();it!=veVersionList->end();it++){
                if(it->WriteLock.load()==TID) it->WriteLock.store(0);
            }
        }
        for(auto vertex:outVertexKeys){
            auto veVersionList = &(*outMap)[vertex];
            for(auto it=veVersionList->begin();it!=veVersionList->end();it++){
                if(it->WriteLock.load()==TID) it->WriteLock.store(0);
            }
        }
    }
    success = WriteVEAOF(vv);
    if(success){
        // 只有处于ReadSet头部的TID可以移除，其余的需要保留以备其后的事务回滚
        // 维护readTs的变更在回滚下保持一致
        for(auto x: tx->ReadSet){
            auto key = x.first;
            for(auto tp:x.second){
                auto trueKey = key+std::to_string(tp.version);
                auto v = &ReadSets[trueKey];
                 // 将全局读集合中当前事务标记删除
                auto it = v->begin();
                for(;it!=v->end();it++){
                    if(it->TID==TID){
                        it->Deleted = true;
                        break;
                    }
                }
                int cnt = 0;
                int v_length = v->size();
                // 移除所有可以移除的过期事务，包含本身
                for(int i = 0; i < v_length; i++){
                    if(!(*v)[i].Deleted){
                        break;
                    }
                    cnt++;
                }
                v->erase(v->begin(),v->begin()+cnt);
            }
        }
        // 从活跃事务集以及事务注册列表中删除当前成功提交事务
        this->ActiveTX.erase(TID);
        delete(tx);
        this->TXs.erase(TID);
    }
    return success;
}

// 事务回滚时，直接移除事务
bool TransactionManager::Abort(int64_t TID){
    using defer=std::shared_ptr<void>;
    GetReadLock();
    defer(nullptr,[&](...){
        Unlock();
    });
    auto tx = this->TXs[TID];
    // 回滚读操作，生成read-ts的aof
    for(auto x: tx->ReadSet){
        auto key = x.first;
        for(auto tp:x.second){
            if(tp.deltaTs==0) continue;
            std::cout<<"rollback read: "<<key<<" "<<tp.version<<" "<<tp.deltaTs<<"\n";
            RollbackReadItem(key,TID,tp.version,tp.deltaTs);
        }
    }
    // 回滚写操作
    for(auto x: tx->WriteSet){
        auto key = x.first;
        for(auto tp:x.second){
            if(tp.operation=='a') RollbackAddItem(key,tp.version);
            else if(tp.operation=='d') RollbackDeleteItem(key,tp.version);
            else{std::cout<<"Undefined operation "<<tp.operation<<"\n"; return false;}
        }
    }

    // UndoWriteSets中的操作，需要移除占位版本
    for(auto x: tx->UndoWriteSet){
        RollbackAddItem(x.first,TID);
    }

    // 回滚VE Map
    std::set<std::string> rollbackVertexKeys;
    for(auto x: tx->EdgeIndexes){
        auto srcID = x.srcID;
        auto dstID = x.dstID;
        rollbackVertexKeys.emplace(srcID);
        rollbackVertexKeys.emplace(dstID);
    }
    for(auto x: rollbackVertexKeys){
        RollbackVEItem(x,TID);
    }

    // 直接删除读集合中对应项
    for(auto x: tx->ReadSet){
        auto key = x.first;
        for(auto tp:x.second){
            auto trueKey = key+std::to_string(tp.version);
            auto v = &ReadSets[trueKey];
            for(auto it=v->begin();it!=v->end();it++){
                if(it->TID==TID){
                    v->erase(it);
                    break;
                }
            }
        }
    }
    
    // 移除事务
    this->ActiveTX.erase(TID);
    delete(tx);
    this->TXs.erase(TID);
    return true;
}


void TransactionManager::PrintActiveTX(){
    std::cout<<"active TX: "<<std::endl;
    for(auto x:this->ActiveTX){
        std::cout<<x<<" ";
    }
    std::cout<<"\n";
    return;
}

void TransactionManager::PrintTX(){
    for(auto x:this->TXs){
        std::cout<<x.first<<": "<<x.second->TID<<"\n";
    }
}

void TransactionManager::PrintReadSets(){
    for(auto x:this->ReadSets){
        std::cout<<x.first<<": ";
        for(auto y:x.second){
            std::cout<<y.TID<<"+"<<y.Deleted<<" ";
        }
        std::cout<<"\n";
    }
}

void TransactionManager::PrintIndexMap(){
    auto indexMap = this->GlobalMap.IndexMap;
    std::cout<<"print index map begin\n";
    for(auto it:indexMap){
        std::cout<<"key: "<<it.first<<", length:"<<it.second.size()<<"\n";
        auto l = it.second;
        std::cout<<"value: ";
        for(auto tp:l){
            std::cout<<tp.WriteLock<<" "<<tp.ReadTs<<" "<<tp.BeginTs<<", ";
        }
        std::cout<<"\n";
    }
    std::cout<<"print index map end\n";
}

void TransactionManager::PrintVEMap(){
    auto inMap = this->GlobalMap.InEdges;
    auto outMap = this->GlobalMap.OutEdges;
    std::cout<<"print in edges begin";
    for(auto it:inMap){
        std::cout<<"\nvertex: "<<it.first;
        auto l = it.second;
        std::cout<<"\nversions: ";
        for(auto tp:l){
            std::cout<<"\nversion:"<<tp.WriteLock<<" "<<tp.ReadTs<<" "<<tp.BeginTs<<"\n";
            for(auto tt:tp.InsertEdges){
                std::cout<<"insert ";
                std::cout<<tt.EdgeID<<" "<<tt.EdgeType<<"; ";
            }
            for(auto tt:tp.DeleteEdges){
                std::cout<<"delete ";
                std::cout<<tt.EdgeID<<" "<<tt.EdgeType<<"; ";
            }     
        }
    }
    std::cout<<"\nprint in edges end";
    std::cout<<"\nprint out edges begin";
    for(auto it:outMap){
        std::cout<<"\nvertex: "<<it.first;
        auto l = it.second;
        std::cout<<"\nversions: ";
        for(auto tp:l){
            std::cout<<"\nversion:"<<tp.WriteLock<<" "<<tp.ReadTs<<" "<<tp.BeginTs<<"\n";
            for(auto tt:tp.InsertEdges){
                std::cout<<"insert ";
                std::cout<<tt.EdgeID<<" "<<tt.EdgeType<<"; ";
            }
            for(auto tt:tp.DeleteEdges){
                std::cout<<"delete ";
                std::cout<<tt.EdgeID<<" "<<tt.EdgeType<<"; ";
            }     
        }
    }
    std::cout<<"\nprint out edges end\n";
}

bool TransactionManager::WriteIndexAOF(std::vector<IndexAOF> v){
    std::cout<<"writeIndexAof, length="<<v.size()<<"\n";
    if(v.size()==0) return true;
    bool success = IndexAOFBuffer->enqueue_bulk(v.begin(),v.size());
    if(!success) return false;
    int length = IndexAOFBuffer->size_approx();
    std::cout<<"approx size:"<<length<<"\n";
    if(length>=1){
        std::string fname = IndexAOFFileName;
        if(reWriteFlag.load()) fname += "_tp";
        std::ofstream ofs(fname,std::ios::app);
        if(!ofs){
            std::cout<<"open output fail\n";
            return false;
        }
        std::stringstream ss;
        for(int i = 0; i < length; i++){
            IndexAOF item;
            if(IndexAOFBuffer->try_dequeue(item)){
                std::string s;
                IndexAOFEncode(item,s);
                ss<<s;
            }
        }
        ofs<<ss.str();  //need test
        ofs.close();
    }
    return true;
}

bool TransactionManager::WriteVEAOF(std::vector<VEAOF> v){
    std::cout<<"writeVEAof, length="<<v.size()<<"\n";
    if(v.size()==0) return true;
    bool success = VEAOFBuffer->enqueue_bulk(v.begin(),v.size());
    if(!success) return false;
    int length = VEAOFBuffer->size_approx();
    if(length>=1){
        std::string fname = VEAOFFileName;
        std::ofstream ofs(fname,std::ios::app);
        if(!ofs){
            std::cout<<"open output fail\n";
            return false;
        }
        std::stringstream ss;
        for(int i = 0; i < length; i++){
            VEAOF item;
            if(VEAOFBuffer->try_dequeue(item)){
                std::string s;
                VEAOFEncode(item,s);
                ss<<s;
            }
        }
        ofs<<ss.str();  //need test
        ofs.close();
    }
    return true;
}

bool TransactionManager::RollbackReadItem(std::string rawKey,int64_t TID,int64_t version,int64_t delta){
    // 生成一条读操作回滚导致的modify aof
    auto beforeTs = TID-delta;
    auto trueKey = rawKey+std::to_string(version);
    auto v = ReadSets[trueKey];
    int64_t behindMax = 0;
    auto x = v.begin();
    for(;x!=v.end();x++){
        if(x->TID==TID) break;
    }
    x++;
    for(;x!=v.end();x++){
        if(x->TID>behindMax) behindMax = x->TID;
    }
    std::cout<<"behindMax="<<behindMax<<"\n";
    std::cout<<"beforeTS="<<beforeTs<<"\n";
    std::cout<<"TID="<<TID<<"\n";
    std::vector<IndexAOF> buf;
    if(behindMax>TID){
        // 生成M{delta} aof
        IndexAOF t{.op='m',.rawKey=rawKey,.version=version,.delta=delta};
        buf.emplace_back(t);
    }else if(beforeTs<behindMax){
        // 生成M{behindMax-beforeTs} aof
        auto newDelta = behindMax-beforeTs;
        IndexAOF t{.op='m',.rawKey=rawKey,.version=version,.delta=newDelta};
        buf.emplace_back(t);
    }

    // 恢复读操作对对应版本造成的read-ts变化
    auto indexMap = &GlobalMap.IndexMap;
    auto it = indexMap->find(rawKey);
    if(it==indexMap->end()){std::cout<<"cannot find rawKey "<<rawKey<<"in index map\n"; return false;}
    for(auto iter=it->second.begin();iter!=it->second.end();iter++){
        if(iter->BeginTs==version){
            iter->ReadTs = beforeTs>behindMax?beforeTs:behindMax;
            break;
        }
    }
    std::cout<<"aof buf size:"<<buf.size()<<"\n";
    
    return WriteIndexAOF(buf);
}


// 回滚Create和Update操作，需要删除占位版本、回滚版本号、反向写入数据库
bool TransactionManager::RollbackAddItem(std::string rawKey,int64_t version){
    std::vector<std::string> deleteKeys;
    auto indexMap = &GlobalMap.IndexMap;
    auto it = indexMap->find(rawKey);
    if(it==indexMap->end()){std::cout<<"cannot find rawKey "<<rawKey<<"in index map\n"; return false;}
    // 释放写锁以及删除当前版本，回滚最新版本号
    for(auto iter=it->second.begin();iter!=it->second.end();iter++){
        if(iter->BeginTs==version){
            deleteKeys.emplace_back(rawKey+std::to_string(version));
            iter->BeginTs=-iter->BeginTs;   // 标记删除当前版本
            // 回滚版本号到前一个版本
            auto prevTs = 0;
            auto prev = iter;
            if(prev!=it->second.begin()){
                do{
                    prev--;
                    if(prev->BeginTs>0){
                        prevTs = prev->BeginTs;
                        break;
                    }
                }while(prev!=it->second.begin());
            }
            auto versionIter = GlobalMap.LatestVersion.find(rawKey);
            if(versionIter==GlobalMap.LatestVersion.end()){
                std::cout<<"Cannot find key "<<rawKey<<" in latest version\n";
                return false;
            }
            versionIter->second.store(prevTs);
        }
        // 释放写锁
        if(iter->WriteLock.load()==version){
            iter->WriteLock.store(0);
        }
    }
    // 删除数据库中的数据
    rocksdbapi.MultiDelete(deleteKeys);
    return true;
}

bool TransactionManager::RollbackDeleteItem(std::string rawKey,int64_t version){
    // 暂时不存在删除操作需要回滚index map的部分，只需要释放写锁
    auto indexMap = &GlobalMap.IndexMap;
    auto it = indexMap->find(rawKey);
    if(it==indexMap->end()){std::cout<<"cannot find rawKey "<<rawKey<<"in index map\n"; return false;}
    for(auto iter=it->second.begin();iter!=it->second.end();iter++){
        if(iter->WriteLock.load()==version) iter->WriteLock.store(0);
    }
    return true;
}

// VE操作全是add操作，释放所有写锁，并删除version对应的所有版本 
bool TransactionManager::RollbackVEItem(std::string vertexKey,int64_t version){
    auto inMap = &GlobalMap.InEdges;
    auto outMap = &GlobalMap.OutEdges;
    auto it = inMap->find(vertexKey);
    if(it!=inMap->end()){
        auto iter = it->second.begin();
        while(iter!=it->second.end()){
            if(iter->WriteLock.load()==version) iter->WriteLock.store(0);
            if(iter->BeginTs==version){
                iter = it->second.erase(iter);
                continue;
            }
            iter++;
        }
    }
    it = outMap->find(vertexKey);
    if(it!=outMap->end()){
        auto iter = it->second.begin();
        while(iter!=it->second.end()){
            if(iter->WriteLock.load()==version) iter->WriteLock.store(0);
            if(iter->BeginTs==version){
                iter = it->second.erase(iter);
                continue;
            }
            iter++;
        }
    }
    return true;
}

// (op+key)+version+(delta), sep=" "
void TransactionManager::IndexAOFEncode(IndexAOF t, std::string& s){
    switch (t.op){
        case 'a':
        s = "a"+t.rawKey+" "+std::to_string(t.version)+" ";
        break;
        case 'm':
        s = "m"+t.rawKey+" "+std::to_string(t.version)+" "+std::to_string(t.delta)+" ";
        break;
        case 'd':
        s = "d"+t.rawKey+" "+std::to_string(t.version)+" ";
        break;
    }
    return;
}

// (pos+key)+version+{insertEdge1,insertEdge2}+{deleteEdge1,deleteEdge2}, sep=" "
void TransactionManager::VEAOFEncode(VEAOF t, std::string& s){
    std::string pos;
    if(t.pos=='1'){
        pos = "1";
    }else{
        pos = "0";
    }
    s = pos+t.vertexKey+" "+std::to_string(t.version)+" ";
    auto iSize = t.insertEdges.size();
    auto dSize = t.deleteEdges.size();
    s+="{";
    if(iSize>0){
        std::string tpInsert = "";
        for(auto i=0;i<iSize;i++){
            if(pos=="0") tpInsert+=t.insertEdges[i].ToOutString()+",";
            else tpInsert+=t.insertEdges[i].ToInString()+",";
        }
        tpInsert.pop_back();
        s+=tpInsert;
    }
    s+="} {";
    if(dSize>0){
        std::string tpDelete = "";
        for(auto i=0;i<dSize;i++){
            if(pos=="0") tpDelete+=t.deleteEdges[i].ToOutString()+",";
            else tpDelete+=t.deleteEdges[i].ToInString()+",";
        }
        tpDelete.pop_back();
        s+=tpDelete;
    }
    s+="} ";
}

// 索引恢复重建
void TransactionManager::Rebuilt(){
    using defer=std::shared_ptr<void>;
    GetWriteLock();
    defer(nullptr,[&](...){
        Unlock();
    });
    this->GlobalMap.Rebuilt();
}

// 重写AOF文件 将临时AOF条目也写入其中，加写锁保证安全性
void TransactionManager::RewriteAOF(){
    using defer=std::shared_ptr<void>;
    GetWriteLock();
    defer(nullptr,[&](...){
        Unlock();
    });
    class MVCCMap tpIndexMap;
    reWriteFlag.store(true);
    tpIndexMap.Rebuilt();
    // 重写aof文件
    std::string IoldFname = IndexAOFFileName;
    std::string InewFname = IoldFname+"_new";
    std::string tpFname = IoldFname+"_tp";
    std::vector<IndexAOF> tpAOFBuffer;
    std::ofstream ofs(InewFname);
    std::stringstream ss;
    std::ifstream ifs(tpFname);
    if(!ofs){
        std::cout<<"open rewrite file fail\n";
        return;
    }

    for(const auto it:tpIndexMap.IndexMap){
        auto key = it.first;
        auto versionList = it.second;
        if(versionList.empty()) continue;
        for(const auto ver:versionList){
            IndexAOF t{'a',key,ver.BeginTs};
            std::string s;
            IndexAOFEncode(t,s);
            ss<<s;
            if(ver.BeginTs!=ver.ReadTs){
                IndexAOF t{'m',key,ver.BeginTs,ver.ReadTs-ver.BeginTs};
                std::string s;
                IndexAOFEncode(t,s);
                ss<<s;
            }
        }
    }
    if(ifs){ 
        ss<<ifs.rdbuf();
        ifs.close();
        std::remove(tpFname.c_str());
    }
    ofs<<ss.str();
    ofs.close();
    std::rename(InewFname.c_str(),IoldFname.c_str());

    IoldFname = VEAOFFileName;
    InewFname = IoldFname+"_new";
    tpFname = IoldFname+"_tp";
    std::vector<VEAOF> ttpAOFBuffer;
    std::ofstream offs(InewFname);
    std::stringstream sss;
    std::ifstream iffs(tpFname, std::ios::in);
    if(!offs){
        std::cout<<"open rewrite file fail\n";
        return;
    }
    // 重写出边和入边的AOF
    for(auto it:tpIndexMap.OutEdges){
        auto key = it.first;
        auto versionList = it.second;
        if(versionList.empty()) continue;
        for(const auto ver:versionList){
            VEAOF t{'0',key,ver.BeginTs,ver.InsertEdges,ver.DeleteEdges};
            std::string s;
            VEAOFEncode(t,s);
            sss<<s;
        }
    }
    for(auto it:tpIndexMap.InEdges){
        auto key = it.first;
        auto versionList = it.second;
        if(versionList.empty()) continue;
        for(const auto ver:versionList){
            VEAOF t{'1',key,ver.BeginTs,ver.InsertEdges,ver.DeleteEdges};
            std::string s;
            VEAOFEncode(t,s);
            sss<<s;
        }
    }
    if(iffs){
        sss<<iffs.rdbuf();
        iffs.close();
        std::remove(tpFname.c_str());
    }
    offs<<sss.str();
    offs.close();
    std::rename(InewFname.c_str(),IoldFname.c_str());
    
    // 更新内存索引并写入临时文件中的内容
    this->GlobalMap.IndexMap = std::move(tpIndexMap.IndexMap);
    this->GlobalMap.InEdges = std::move(tpIndexMap.InEdges);
    this->GlobalMap.OutEdges = std::move(tpIndexMap.OutEdges);

    reWriteFlag.store(false);
}

bool TransactionManager::IsVertex(std::string key){
    if(key[0]=='e') return false;
    return true;
}

// 读索引，读数据库，写入全局ReadSets，写入ReadSet
// 如果事务内有UndoWriteSets，则需要优先读UndoWriteSets
std::string TransactionManager::Read(int64_t TID, std::string key){
    using defer=std::shared_ptr<void>;
    GetReadLock();
    defer(nullptr,[&](...){
        Unlock();
    });
    auto tx = this->TXs[TID];
    auto undoIter = tx->UndoWriteSet.find(key);
    // 查找undo集合中是否有这个key的相关信息，以最后的版本为准
    if(undoIter!=tx->UndoWriteSet.end()){
        auto item = undoIter->second;
        auto newKey = key+std::to_string(item.version);
        return rocksdbapi.Get(newKey);
    }
    auto resp = this->GlobalMap.ReadIndex(TID,key);
    if(!resp.success||!resp.exist) return "";
    auto newKey = key+std::to_string(resp.beginTs);
    auto res = rocksdbapi.Get(newKey);
    std::cout<<"delta:"<<resp.deltaTs<<std::endl;
    // 写入全局ReadSets
    auto readSetsIter = this->ReadSets.find(newKey);
    if(readSetsIter==this->ReadSets.end()){
        std::vector<TXStatus> vv;
        TXStatus tt{.TID=TID,.Deleted=false};
        vv.emplace_back(tt);
        this->ReadSets.emplace(std::make_pair(newKey,vv));
    }else{
        TXStatus tt{.TID=TID,.Deleted=false};
        bool existFlag = false;
        for(auto iter = readSetsIter->second.begin();iter!=readSetsIter->second.end();iter++){
            if(iter->TID==TID){
                existFlag = true;
                break;
            }
        }
        // 避免重复写入ReadSets
        if(!existFlag) readSetsIter->second.emplace_back(tt);
    }

    // 写入ReadSet
    auto readIter = tx->ReadSet.find(key);
    RItem r;
    r.deltaTs = resp.deltaTs;
    r.version = resp.beginTs;
    if(readIter==tx->ReadSet.end()){
        std::vector<RItem> v;
        v.emplace_back(r);
        tx->ReadSet.insert(std::make_pair(key,v));
    }else{
        readIter->second.emplace_back(r);
    }

    return res;
}

// 校验key是否存在在索引里，并完成read的AOF修改
ReadResp TransactionManager::CheckIfNotExist(int64_t TID,std::string key){
    ReadResp res;
    res.success = false;
    auto tx =this->TXs[TID];
    auto resp = this->GlobalMap.ReadIndex(TID,key);
    if(!resp.success) return res;
    if(resp.deltaTs!=0){
        auto readIter = tx->ReadSet.find(key);
        RItem r;
        r.deltaTs = resp.deltaTs;
        r.version = resp.beginTs;
        if(readIter==tx->ReadSet.end()){
            std::vector<RItem> v;
            v.emplace_back(r);
            tx->ReadSet.emplace(std::make_pair(key,v));
        }else{
            readIter->second.emplace_back(r);
        }
    }
    res.success = true;
    res.exist = resp.exist;
    return res;
}

bool TransactionManager::CreateIndexMap(int64_t TID, std::string key,std::string value){
    auto tx = this->TXs[TID];
    // 覆盖写入，写在UndoWriteSet上；直接写，需要写入WriteSet
    auto resp = this->GlobalMap.CreateIndex(TID,key);
    if(!resp.success) return false;
    if(resp.needRCU){
        auto undoSet = &tx->UndoWriteSet;
        WItem w{TID,'a'};
        (*undoSet)[key] = w;
    }else{
        auto writeIter = tx->WriteSet.find(key);
        WItem w;
        w.operation = 'a';
        w.version = TID;
        std::vector<WItem> v;
        v.emplace_back(w);
        if(writeIter==tx->WriteSet.end()){
            tx->WriteSet.emplace(std::make_pair(key,v));
        }else{
            writeIter->second=v;
        }
    }

    // 写底层kvstore
    auto newKey = key+std::to_string(TID);
    rocksdbapi.Put(newKey,value);
    return true;
}

// （读索引，）RCU写索引，写UndoWriteSet，（写VEMap，写InsertEdges）写入数据库
bool TransactionManager::Create(int64_t TID, std::string key, std::string value, bool ifNotExist=false){
    using defer=std::shared_ptr<void>;
    GetReadLock();
    defer(nullptr,[&](...){
        Unlock();
    });
    // if not exist需要先检查
    if(ifNotExist) {
        auto res = CheckIfNotExist(TID,key);
        if(!res.success) return false;
        if(res.exist) return true;
    }

    auto tx = this->TXs[TID];
    bool keyIsVertex = IsVertex(key);
    if(keyIsVertex){
        return CreateIndexMap(TID,key,value);
    }

    // 新建边
    Edge e;
    e.FromString(key);
    // 更新点边关系
    auto success = this->GlobalMap.WriteVE(TID,e,'a');
    if(!success) return false;

    // 写两次IndexMap
    success = CreateIndexMap(TID,e.ToInString(),value);
    if(!success) return false;
    success = CreateIndexMap(TID,e.ToOutString(),value);
    if(!success) return false;

    // 更新事务内部插入边集
    auto indexes = tx->EdgeIndexes;
    auto indexSize = indexes.size();
    auto index = indexSize;
    for(int i=0; i<indexSize; i++){
        if(indexes[i].EdgeID==e.EdgeID&&indexes[i].GetDstID()==e.GetDstID()&&indexes[i].GetSrcID()==e.GetSrcID()){
            index = i;
            break;
        }
    }
    if(index==indexSize){
        tx->EdgeIndexes.emplace_back(e);
    }
    tx->InsertEdges.set(index);
    return true;
}

// 更新索引，写WriteSet，写入数据库
bool TransactionManager::Update(int64_t TID, std::string key, std::string value){
    using defer=std::shared_ptr<void>;
    GetReadLock();
    defer(nullptr,[&](...){
        Unlock();
    });
    auto tx = this->TXs[TID];
    auto resp = this->GlobalMap.UpdateIndex(TID,key);
    if(!resp.success) return false;

    WItem w;
    w.operation = 'a';
    w.version = TID;
    auto undoSet = &tx->UndoWriteSet;
    // 该事务已经有一个RCU写了，后续的更新也将写在这上面
    if(undoSet->find(key)!=undoSet->end()){
        (*undoSet)[key]=w;
    }else{
        auto writeIter = tx->WriteSet.find(key);
        if(writeIter==tx->WriteSet.end()){
            std::vector<WItem> v;
            v.emplace_back(w);
            tx->WriteSet.emplace(std::make_pair(key,v));
        }else{
            writeIter->second.emplace_back(w);
        }
    }

    auto newKey = key+std::to_string(TID);
    rocksdbapi.Put(newKey,value);
    return true;
}

bool TransactionManager::DeleteIndexMap(int64_t TID, std::string key){
    auto tx = this->TXs[TID];
    auto resp = this->GlobalMap.DeleteIndex(TID,key);
    if(!resp.success) return false;
    WItem w;
    w.operation = 'd';
    w.version = 0;
    std::vector<WItem> v;
    v.emplace_back(w);
    if(resp.needRCU){
        auto undoSet = &tx->UndoWriteSet;
        (*undoSet)[key] = w;
    }else{
        auto writeIter = tx->WriteSet.find(key);
        if(writeIter==tx->WriteSet.end()){
            tx->WriteSet.emplace(std::make_pair(key,v));
        }else{
            writeIter->second=v;
        }
    }
    return true;
}

// RCU删除索引，WriteSet对应key清空，（写VEMap，写DeleteEdges）不删除数据库中的键
bool TransactionManager::Delete(int64_t TID, std::string key, bool withEdge=false){
    using defer=std::shared_ptr<void>;
    GetReadLock();
    defer(nullptr,[&](...){
        Unlock();
    });
    auto tx = this->TXs[TID];
    bool keyIsVertex = IsVertex(key);
    if(keyIsVertex){
        bool success = DeleteIndexMap(TID,key);
        if(!success) return false;
        if(withEdge){
            auto outIter = this->GlobalMap.OutEdges.find(key);
            if(outIter!=this->GlobalMap.OutEdges.end()){
                auto edgeVersions = outIter->second;
                std::unordered_set<Edge,EdgeKeyHash,EdgeKeyEqual> edges;
                for(auto v:edgeVersions){
                    if(v.BeginTs>TID||v.WriteLock.load()!=TID){
                        break;
                    }
                    auto deleted = v.DeleteEdges;
                    auto inserted = v.InsertEdges;
                    for(auto e:inserted){
                        edges.insert(e);
                    }
                    for(auto e:deleted){
                        edges.erase(e);
                    }
                }
                for(auto edge:edges){
                    Delete(TID,edge.ToOutString());
                    Delete(TID,edge.ToInString());
                }
            }
            auto inIter = this->GlobalMap.InEdges.find(key);
            if(inIter!=this->GlobalMap.InEdges.end()){
                auto edgeVersions = inIter->second;
                std::unordered_set<Edge,EdgeKeyHash,EdgeKeyEqual> edges;
                for(auto v:edgeVersions){
                    if(v.BeginTs>TID||v.WriteLock.load()!=TID){
                        break;
                    }
                    auto deleted = v.DeleteEdges;
                    auto inserted = v.InsertEdges;
                    for(auto e:inserted){
                        edges.insert(e);
                    }
                    for(auto e:deleted){
                        edges.erase(e);
                    }
                }
                for(auto edge:edges){
                    Delete(TID,edge.ToOutString());
                    Delete(TID,edge.ToInString());
                }
            }
        }
        return true;
    }

    // 边需要删除两次索引
    Edge e;
    e.FromString(key);
    bool flag = DeleteIndexMap(TID,e.ToInString());
    if(!flag) return false;
    flag = DeleteIndexMap(TID,e.ToOutString());
    if(!flag) return false;

    // 更新点边关系
    auto success = this->GlobalMap.WriteVE(TID,e,'d');
    if(!success) return false;

    auto indexes = tx->EdgeIndexes;
    auto indexSize = indexes.size();
    auto index = indexSize;
    for(int i=0; i<indexSize; i++){
        if(indexes[i].EdgeID==e.EdgeID&&indexes[i].GetDstID()==e.GetDstID()&&indexes[i].GetSrcID()==e.GetSrcID()){
            index = i;
            break;
        }
    }
    if(index==indexSize){
        tx->EdgeIndexes.emplace_back(e);
    }
    tx->DeleteEdges.set(index);
    return true;
}

inline std::string joinStr(const std::vector<std::string>& v, std::string sep){
    std::string res = "";
    for(auto i = v.begin(); i!=v.end(); i++){
        res += *i;
        if(i!=v.end()-1){
            res += sep;
        }
    }
    return res;
}


// 对IndexMap的一个版本链进行GC，v长度需要大于1 生成AOF——delete整个key，再依次add版本
std::string singleIndexGC(std::string rawKey, int64_t minTID, bool flag, std::list<IndexVersion>& v){
    std::vector<std::string> keys;
    std::list<IndexVersion> newV;

    bool shoulDelete = false;
    for(auto i=v.rbegin();i!=v.rend();i++){
        if(i->BeginTs<0){   // 软删除版本，跳过
            continue;
        }
        if(flag && !shoulDelete){   // 情况1下的最大公开版本
            newV.emplace_front(*i);
            shoulDelete = true;
            continue;
        }
        if(!flag && i->BeginTs>=minTID){   // 情况2下需要保留的版本
            newV.emplace_front(*i);
            continue;
        }
        if(!shoulDelete){       // 情况2下小于minTID的最大公开版本
            newV.emplace_front(*i);
            shoulDelete = true;
            continue;       
        }
        // 剩下都是需要删除的版本
        keys.emplace_back(rawKey+std::to_string(i->BeginTs));
    }

    v = newV;
    return joinStr(keys," ");
}

// 对VEMap的一个版本链进行GC，需要从头遍历进行版本合并，VEMap没有软删除
std::string singleVEGC(std::string rawKey,int64_t minTID, bool flag, std::list<VEVersion>& v){
    std::vector<std::string> keys;
    std::unordered_map<std::string,int> edgeIndex;
    std::unordered_map<int,std::string> edgeReverseIndex;
    std::unordered_map<int,char> resMap;    // 'a'代表add，'d'代表delete，'n'代表none
    int cnt = 0;
    int total = 0;
    int64_t latestVersion = 0;
    for(auto iter:v){
        if(!flag && iter.BeginTs>=minTID) break;
        total++;
        latestVersion = iter.BeginTs;
        auto insertEdge = iter.InsertEdges;
        auto deleteEdge = iter.DeleteEdges;
        for(const auto it:insertEdge){
            auto edgeStr = it.ToOutString();
            auto eit = edgeIndex.find(edgeStr);
            int index = 0;
            if(eit==edgeIndex.end()){
                index = cnt;
                edgeReverseIndex[cnt] = edgeStr;
                edgeIndex[edgeStr] = cnt++;
            }else{
                index = eit->second;
            }
            // 更新resMap
            auto mit = resMap.find(index);
            if(mit==resMap.end()){
                resMap[index] = 'a';
            }else{
                if(mit->second=='d'){
                    resMap[index] = 'n';
                }else if(mit->second=='n'){
                    resMap[index] = 'a';
                }
            }
        }
        for(const auto it:deleteEdge){
            auto edgeStr = it.ToOutString();
            auto eit = edgeIndex.find(edgeStr);
            int index = 0;
            if(eit==edgeIndex.end()){
                index = cnt;
                edgeReverseIndex[cnt] = edgeStr;
                edgeIndex[edgeStr] = cnt++;
            }else{
                index = eit->second;
            }
            // 更新resMap
            auto mit = resMap.find(index);
            if(mit==resMap.end()){
                continue;  // 不允许预先删除
            }else{
                if(mit->second=='a'){
                    resMap[index] = 'n';
                }
            }
        }
    }
    VEVersion newv;
    newv.BeginTs = latestVersion;
    newv.ReadTs = latestVersion;
    newv.WriteLock = 0;
    for(auto &[k,v]:resMap){
        if(v=='n') continue;
        Edge e;
        e.FromString(edgeReverseIndex[k]);
        if(v=='a'){       
            newv.InsertEdges.emplace_back(e);
        }
        // 正常情况现存版本不会有delete边，所以忽略
        // else if(v=='d'){
        //     newv.DeleteEdges.emplace_back(e);
        // }
    }

    // 将合并后的版本替代之前的版本
    auto tpIter = v.begin();
    for(int i = 0; i < total-1; i++){
        keys.emplace_back(rawKey+std::to_string(tpIter->BeginTs));
        tpIter++;
    }

    for(int i = 0; i < total-1; i++){
        v.pop_front();
    }
    v.emplace_front(std::move(newv));

    return joinStr(keys," ");
}


// GC，移除被删除的版本，合并过时版本
void TransactionManager::GC(){
    using defer=std::shared_ptr<void>;
    GetWriteLock();
    defer(nullptr,[&](...){
        Unlock();
    });
    auto minTID = this->GetMinTX();
    bool compressAll = minTID==0?true:false;
    
    auto indexMap = &this->GlobalMap.IndexMap;
    auto outEdges = &this->GlobalMap.OutEdges;
    auto inEdges = &this->GlobalMap.InEdges;

    int threadCnt1,threadCnt2,threadCnt3 = 0;
    std::future<std::string> indexFutures[indexMap->size()];
    for(auto &[k,v]:*indexMap){
        if(v.size()==1){
            indexFutures[threadCnt1++] = std::async(std::launch::async,singleIndexGC,k,minTID,compressAll,std::ref(v));
        }
    }
    std::future<std::string> outFutures[outEdges->size()];
    for(auto &[k,v]:*outEdges){
        if(v.size()==1){
            outFutures[threadCnt2++] = std::async(std::launch::async,singleVEGC,k,minTID,compressAll,std::ref(v));
        }
    }
    std::future<std::string> inFutures[inEdges->size()];
    for(auto &[k,v]:*inEdges){
        if(v.size()==1){
            inFutures[threadCnt3++] = std::async(std::launch::async,singleVEGC,k,minTID,compressAll,std::ref(v));
        }
    }

    // 移除数据库中的键值
    std::set<std::string> keySet;
    for(int i = 0; i < threadCnt1; i++){
        auto resStr = indexFutures[i].get();
        auto tp = split(resStr," ");
        for(const auto it:tp){
            keySet.emplace(it);
        }
    }
    for(int i = 0; i < threadCnt2; i++){
        auto resStr = outFutures[i].get();
        auto tp = split(resStr," ");
        for(const auto it:tp){
            keySet.emplace(it);
        }
    }
    for(int i = 0; i < threadCnt3; i++){
        auto resStr = inFutures[i].get();
        auto tp = split(resStr," ");
        for(const auto it:tp){
            keySet.emplace(it);
        }
    }
    std::vector<std::string> keyVec;
    keyVec.assign(keySet.begin(),keySet.end());
    rocksdbapi.MultiDelete(keyVec);


    // 生成AOF
    std::vector<IndexAOF> buf;
    for(auto &[k,v]:*indexMap){
        IndexAOF t{.op='d',.rawKey=k,.version=0};
        buf.emplace_back(std::move(t));
        for(const auto iter:v){
            IndexAOF t{.op='a',.rawKey=k,.version=iter.BeginTs};
            buf.emplace_back(std::move(t));
        }
    }

    std::vector<VEAOF> buff;
    for(auto &[k,v]:*outEdges){
        VEAOF t{.pos='0',.vertexKey=k,.version=0};
        buff.emplace_back(std::move(t));
        for(const auto iter:v){
            VEAOF t{.pos='0',.vertexKey=k,.version=iter.BeginTs,.insertEdges=iter.InsertEdges,.deleteEdges=iter.DeleteEdges};
            buff.emplace_back(std::move(t));
        }
    }
    for(auto &[k,v]:*inEdges){
        VEAOF t{.pos='1',.vertexKey=k,.version=0};
        buff.emplace_back(std::move(t));
        for(const auto iter:v){
            VEAOF t{.pos='1',.vertexKey=k,.version=iter.BeginTs,.insertEdges=iter.InsertEdges,.deleteEdges=iter.DeleteEdges};
            buff.emplace_back(std::move(t));
        }
    }


    // 移除版本链为空的键
    for(auto it=indexMap->begin();it!=indexMap->end();){
        if(it->second.size()==0) indexMap->erase(it++);
        else it++;
    }
    for(auto it=outEdges->begin();it!=outEdges->end();){
        if(it->second.size()==0) outEdges->erase(it++);
        else it++;
    }
    for(auto it=inEdges->begin();it!=inEdges->end();){
        if(it->second.size()==0) inEdges->erase(it++);
        else it++;
    }

    WriteIndexAOF(buf);
    WriteVEAOF(buff);

    return;
}

// 获取顶点的所有邻居，pos=1为出边，pos=-1为入边，pos=0为双向边
std::vector<std::string> TransactionManager::GetNeighbors(int64_t TID, std::string vertexKey, std::unordered_set<std::string> edgeType, int pos){
    std::vector<std::string> result;
    std::vector<VEAOF> vv;
    if(pos==1){
        auto res = this->GlobalMap.ReadVEMap(TID,vertexKey,'0');
        if(!res.success) return result;
        for(auto &edge:res.edges){
            if(edgeType.count(edge.GetEdgeType())==0) continue;
            result.emplace_back(edge.ToOutString());
        }
        if(res.delta!=0){
            VEAOF v{.pos='0',.vertexKey=vertexKey,.version=res.delta};
            vv.emplace_back(std::move(v));
        }
    }else if(pos==-1){
        auto res = this->GlobalMap.ReadVEMap(TID,vertexKey,'1');
        if(!res.success) return result;
        for(auto &edge:res.edges){
            if(edgeType.count(edge.GetEdgeType())==0) continue;
            result.emplace_back(edge.ToInString());
        }
        if(res.delta!=0){
            VEAOF v{.pos='1',.vertexKey=vertexKey,.version=res.delta};
            vv.emplace_back(std::move(v));
        }
    }else{
        auto res = this->GlobalMap.ReadVEMap(TID,vertexKey,'0');
        if(!res.success) return result;
        for(auto &edge:res.edges){
            if(edgeType.count(edge.GetEdgeType())==0) continue;
            result.emplace_back(edge.ToOutString());
        }
        if(res.delta!=0){
            VEAOF v{.pos='0',.vertexKey=vertexKey,.version=res.delta};
            vv.emplace_back(std::move(v));
        }
        res = this->GlobalMap.ReadVEMap(TID,vertexKey,'1');
        if(!res.success) return result;
        for(auto &edge:res.edges){
            if(edgeType.count(edge.GetEdgeType())==0) continue;
            result.emplace_back(edge.ToInString());
        }
        if(res.delta!=0){
            VEAOF v{.pos='1',.vertexKey=vertexKey,.version=res.delta};
            vv.emplace_back(std::move(v));
        }
    }
    // TODO 写入修改的read-ts AOF
    // if(vv.size()!=0){
    //     WriteVEAOF(vv);
    // }
    return result;
}