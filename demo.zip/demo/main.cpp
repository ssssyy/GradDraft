#include "TXManager.h"
#include <iostream>
#include <cstring>

using namespace std;

TransactionManager TXMan;

extern vector<string> split(const string&,const string&);

void parse(string cmd){
    if(cmd[0]=='#') return;
    auto res = split(cmd," ");
    if(res.size()<1) return;
    auto op = res[0];
    if(op=="reg"){
        int64_t TID = atoi(res[1].c_str());
        TXMan.Register(TID);
    }
    else if(op=="commit"){
        int64_t TID = atoi(res[1].c_str());
        TXMan.Commit(TID);
    }
    else if(op=="abort"){
        int64_t TID = atoi(res[1].c_str());
        TXMan.Abort(TID);
    }
    else if(op=="max"){
        cout<<TXMan.GetMaxTX()<<endl;
    }
    else if(op=="min"){
        cout<<TXMan.GetMinTX()<<endl;
    }
    else if(op=="read"){
        auto key = res[1];
        int64_t TID = atoi(res[2].c_str());
        auto val = TXMan.Read(TID,key);
        cout<<val<<endl;
    }
    else if(op=="create"){
        auto key = res[1];
        auto val = res[2];
        int64_t TID = atoi(res[3].c_str());
        auto flag = false;
        if(res.size()==5) flag = true;
        auto succ = TXMan.Create(TID,key,val,flag);
        if(succ) cout<<"true"<<endl;
        else cout<<"false"<<endl;
    }
    else if(op=="update"){
        auto key = res[1];
        auto val = res[2];
        int64_t TID = atoi(res[3].c_str());
        auto succ = TXMan.Update(TID,key,val);
        if(succ) cout<<"true"<<endl;
        else cout<<"false"<<endl;
    }
    else if(op=="delete"){
        auto key = res[1];
        int64_t TID = atoi(res[2].c_str());
        auto succ = TXMan.Delete(TID,key,false);
        if(succ) cout<<"true"<<endl;
        else cout<<"false"<<endl;
    }

    else if(op=="rebuilt"){
        TXMan.Rebuilt();
    }
    else if(op=="rewrite"){
        TXMan.RewriteAOF();
    }
    else if(op=="GC"){
        TXMan.GC();
    }
    else if(op=="getNeighbors"){
        auto key = res[1];
        int64_t TID = atoi(res[2].c_str());
        auto edgeType = res[3];
        unordered_set<string> edgeTypes;
        edgeTypes.emplace(edgeType);
        int pos = atoi(res[4].c_str());
        auto res = TXMan.GetNeighbors(TID,key,edgeTypes,pos);
        for(auto& x:res){
            cout<<x<<" ";
        }
        cout<<endl;
    }

    else if(op=="printATX"){
        TXMan.PrintActiveTX();
    }
    else if(op=="printTX"){
        TXMan.PrintTX();
    }
    else if(op=="printRS"){
        TXMan.PrintReadSets();
    }
    else if(op=="printIndex"){
        TXMan.PrintIndexMap();
    }
    else if(op=="printVE"){
        TXMan.PrintVEMap();
    }
}


int main(){
    string s;
    while(getline(cin,s)){
        parse(s);
    }
}

