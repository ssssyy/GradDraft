#include "TXManager.h"



// 获取版本号以及read-ts变更，若Resp.delta=0，表示未更新
ReadResp MVCCMap::ReadIndex(int64_t TID, std::string rawKey){
    ReadResp resp;
    resp.success = true;
    resp.exist = false;
    auto it = IndexMap.find(rawKey);
    if(it==IndexMap.end()) return resp;
    if(it->second.empty()) return resp;
    auto riter = it->second.rbegin();
    #if IsolationLevel==1 // RC
    do {
        //反向找到第一个可以读的公开版本
        if(riter->BeginTs>0){
            auto cntVal = riter->WriteLock.load();
            if(cntVal==0||cntVal==TID){
                int64_t delta = 0;
                if(riter->ReadTs<TID){  // 更新readTs为TID
                    delta = TID-riter->ReadTs;
                    riter->ReadTs = TID;
                }
                resp.beginTs = riter->BeginTs;
                resp.deltaTs = delta;
                resp.success = true;
                resp.exist = true;
                return resp;
            }
        }
        riter++;
    } while (riter!=it->second.rend());
    #elif IsolationLevel==2 // RR
    do {
        //反向找到第一个可以读的公开版本
        if(riter->BeginTs<=TID&&riter->BeginTs>0){
            auto cntVal = riter->WriteLock.load();
            if(cntVal==0||cntVal==TID){
                int64_t delta = 0;
                if(riter->ReadTs<TID){  // 更新readTs为TID
                    delta = TID-riter->ReadTs;
                    riter->ReadTs = TID;
                }
                resp.beginTs = riter->BeginTs;
                resp.deltaTs = delta;
                resp.success = true;
                resp.exist = true;
                return resp;
            }
        }
        riter++;
    } while (riter!=it->second.rend());
    #else                   // SERIALIZABLE
    #endif
    
    return resp;
}

// 覆盖写，将新版本写在UndoWriteSets中，原有版本链上写一个空版本并加写锁
WriteResp MVCCMap::CreateIndex(int64_t TID, std::string rawKey){
    WriteResp resp;
    resp.success = true;
    resp.needRCU = false;
    auto it = IndexMap.find(rawKey);
    auto versionIter = LatestVersion.find(rawKey);
    // 当前key不存在，直接创建版本链
    if(it==IndexMap.end()){ 
        if(versionIter==LatestVersion.end()){
            LatestVersion.insert(std::make_pair(rawKey,TID));
        }else{
            LatestVersion[rawKey].store(TID);
        }
        std::list<IndexVersion> l;
        l.emplace_back(IndexVersion{TID,TID,TID});
        IndexMap[rawKey] = l; 
        return resp;
    }
    if(it->second.empty()){
        if(versionIter==LatestVersion.end()){
            LatestVersion.insert(std::make_pair(rawKey,TID));
        }else{
            LatestVersion[rawKey].store(TID);
        }
        it->second.emplace_back(IndexVersion{TID,TID,TID});
        return resp;
    }
    // 当前key存在，使用RCU
    resp.needRCU = true;
    // 查找当前事务是否已经在这个key下有一个版本，如果有则没必要生成一个新版本，因为这个版本一定是锁定了版本链的私有版本
    for(auto itt=it->second.rbegin();itt!=it->second.rend();itt++){
        if(itt->BeginTs==TID) {
            return resp;
        }
    }
    auto riter = it->second.rbegin();
    while(riter!=it->second.rend()&&riter->BeginTs<0) riter++;   // 跳过已删除的版本
    int64_t prevTS = 0;
    if(versionIter==LatestVersion.end()){ // 创建新的最新版本
        LatestVersion.emplace(std::make_pair(rawKey,TID));
    }else{
        auto oldVersion = riter==it->second.rend()?0:riter->BeginTs;
        auto newVersion = TID;
        prevTS = oldVersion;
        if(!versionIter->second.compare_exchange_weak(oldVersion,newVersion)){
            //当前事务持有的不是最新版本，回滚
            resp.success = false;
            return resp;
        }
    }
    if(riter==it->second.rend()){ 
        it->second.emplace_back(IndexVersion(TID,TID,TID));
        return resp;
    }
    auto newVal = TID;
    int64_t oldVal = 0;
    // 禁止迟到的写者写入
    if((riter->WriteLock.compare_exchange_weak(oldVal,newVal)||riter->WriteLock.load()==TID)&&riter->ReadTs<=TID){
        it->second.emplace_back(IndexVersion(TID,TID,TID));    //加一个空版本用来锁上版本链
        // 释放老版本的写锁
        for(auto rriter = ++(it->second.rbegin());rriter!=it->second.rend();rriter++){
            if(rriter->WriteLock.load()==TID){
                rriter->WriteLock.store(0);
                break;
            }
        }
        return resp;
    }
    // 回滚上一步对最新版本号表造成的修改
    riter->WriteLock.store(oldVal);
    versionIter->second.store(prevTS);
    resp.success = false;
    return resp;
}

// 一个事务内对同一个key的多次更新操作记录在同一个版本上
WriteResp MVCCMap::UpdateIndex(int64_t TID,std::string rawKey){
    WriteResp resp;
    resp.success = false;
    auto it = IndexMap.find(rawKey);
    if(it==IndexMap.end()){
        std::cout<<"Cannot find key "<<rawKey<<"in indexMap\n";
        return resp;
    }
    if(it->second.empty()){
        std::cout<<"key "<<rawKey<<" version list empty\n";
        return resp;
    }
    // 查找当前事务是否已经在这个key下有一个版本，如果有则没必要生成一个新版本，因为这个版本一定是锁定了版本链的私有版本
    for(auto itt=it->second.rbegin();itt!=it->second.rend();itt++){
        if(itt->BeginTs==TID) {
            resp.success = true;
            return resp;
        }
    }
    auto riter = it->second.rbegin();
    while(riter!=it->second.rend()&&riter->BeginTs<0) riter++;   // 跳过已删除的版本
    auto versionIter = LatestVersion.find(rawKey);
    if(versionIter==LatestVersion.end()){
        std::cout<<"Cannot find key "<<rawKey<<" in latest version\n";
        return resp;
    }
    auto oldVersion = riter==it->second.rend()?0:riter->BeginTs;
    auto newVersion = TID;
    if(!versionIter->second.compare_exchange_weak(oldVersion,newVersion)){
        //当前事务持有的不是最新版本，回滚
        return resp;
    }
    auto newVal = TID;
    int64_t oldVal = 0;
    if(riter==it->second.rend()){ 
        it->second.emplace_back(IndexVersion(TID,TID,TID));
        resp.success = true;
        return resp;
    }
    // 禁止迟到的写者写入
    if((riter->WriteLock.compare_exchange_weak(oldVal,newVal)||riter->WriteLock.load()==TID)&&riter->ReadTs<=TID){
        it->second.emplace_back(IndexVersion(TID,TID,TID));
       // 释放老版本的写锁
        for(auto rriter = ++(it->second.rbegin());rriter!=it->second.rend();rriter++){
            if(rriter->WriteLock.load()==TID){
                rriter->WriteLock.store(0);
                break;
            }
        }
        resp.success = true;
        return resp;
    }
    // 回滚不成功导致的版本号表修改
    riter->WriteLock.store(oldVal);
    versionIter->second.store(oldVersion);
    return resp;
}

// 操作写入UndoWriteSets，对原版本加锁
WriteResp MVCCMap::DeleteIndex(int64_t TID,std::string rawKey){
    WriteResp resp;
    resp.success = false;
    resp.needRCU = false;
    auto it = IndexMap.find(rawKey);
    if(it==IndexMap.end()) return resp;
    if(it->second.empty()) return resp;
    // 查找当前事务是否已经在这个key下有一个版本，如果有则没必要生成一个新版本，因为这个版本一定是锁定了版本链的私有版本
    resp.needRCU = true;
    for(auto itt=it->second.rbegin();itt!=it->second.rend();itt++){
        if(itt->BeginTs==TID) {
            resp.success = true;
            return resp;
        }
    }
    auto riter = it->second.rbegin();
    while(riter!=it->second.rend()&&riter->BeginTs<0) riter++;   // 跳过已删除的版本
    auto versionIter = LatestVersion.find(rawKey);
    if(versionIter==LatestVersion.end()){
        std::cout<<"Cannot find key "<<rawKey<<" in latest version\n";
        return resp;
    }
    auto oldVersion = riter==it->second.rend()?0:riter->BeginTs;
    auto newVersion = TID;
    if(!versionIter->second.compare_exchange_weak(oldVersion,newVersion)){
        //当前事务持有的不是最新版本，回滚
        return resp;
    }
    auto newVal = TID;
    int64_t oldVal = 0;
    if(riter==it->second.rend()){ 
        it->second.emplace_back(IndexVersion(TID,TID,TID));
        resp.success = true;
        return resp;
    }
    // 禁止迟到的写者写入
    if((riter->WriteLock.compare_exchange_weak(oldVal,newVal)||riter->WriteLock.load()==TID)&&riter->ReadTs<=TID){
        it->second.emplace_back(IndexVersion(TID,TID,TID));    //加一个空版本用来锁上版本链
        // 释放老版本的写锁
        for(auto rriter = ++(it->second.rbegin());rriter!=it->second.rend();rriter++){
            if(rriter->WriteLock.load()==TID){
                rriter->WriteLock.store(0);
                break;
            }
        }
        resp.success = true;
        return resp;
    }
    // 回滚不成功导致的版本号表修改
    riter->WriteLock.store(oldVal);
    versionIter->second.store(oldVersion);
    return resp;
}

// 同时更新InMap和OutMap，只支持单条边插入，一条边的两个表示只会保留一个
// 如果已经有这个版本了则更新在当前版本上
// 先更新index map再更新ve map，所以此处不会有写写冲突
bool MVCCMap::WriteVE(int64_t TID, Edge edge, char op){
    auto srcID = edge.GetSrcID();
    auto dstID = edge.GetDstID();
    VEVersion v(TID,TID,TID);
    if(op=='a'){
        v.InsertEdges.emplace_back(edge);
    }else if(op=='d'){
        v.DeleteEdges.emplace_back(edge);
    }else{
        std::cout<<"Undefined op "<<op<<"\n";
        return false;
    }

    auto it = InEdges.find(dstID);
    if(it==InEdges.end()){
        // 创建新节点
        std::list<VEVersion> l;
        l.emplace_back(v);
        InEdges[dstID] = l;
    }else{
        if(it->second.empty()){  // 创建新版本链
            it->second.emplace_back(v);
        }else{
            for(auto iter=it->second.rbegin();iter!=it->second.rend();iter++){
                if(iter->BeginTs==TID){ // 该事务已经持有的版本
                    if(op=='a'){
                        iter->InsertEdges.emplace_back(edge);
                    }else if(op=='d'){
                        iter->DeleteEdges.emplace_back(edge);
                    }else{
                        std::cout<<"Undefined op "<<op<<"\n";
                        return false;
                    }
                    goto OUTLABEL;
                }
            }
            auto riter = it->second.rbegin();
            while(riter->BeginTs<0) riter++;    // 跳过已删除的版本
            auto newVal = TID;
            int64_t oldVal = 0;
            if(riter->WriteLock.compare_exchange_weak(oldVal,newVal)||riter->WriteLock.load()==TID){
                it->second.emplace_back(v);
                // 释放老版本的写锁
                for(auto rriter = ++(it->second.rbegin());rriter!=it->second.rend();rriter++){
                    if(rriter->WriteLock.load()==TID){
                        rriter->WriteLock.store(0);
                        break;
                    }
                }
                goto OUTLABEL;
            }
            return false;
        }
    }

OUTLABEL:
    it = OutEdges.find(srcID);
    if(it==OutEdges.end()){
        // 创建新节点
        std::list<VEVersion> l;
        l.emplace_back(v);
        OutEdges[srcID] = l;
    }else{
        if(it->second.empty()){  // 创建新版本链
            it->second.emplace_back(v);
        }else{
            for(auto iter=it->second.rbegin();iter!=it->second.rend();iter++){
                if(iter->BeginTs==TID){ // 该事务已经持有的版本
                    if(op=='a'){
                        iter->InsertEdges.emplace_back(edge);
                    }else if(op=='d'){
                        iter->DeleteEdges.emplace_back(edge);
                    }else{
                        std::cout<<"Undefined op "<<op<<"\n";
                        return false;
                    }
                    return true;
                }
            }
            auto riter = it->second.rbegin();
            while(riter->BeginTs<0) riter++;    // 跳过已删除的版本
            auto newVal = TID;
            int64_t oldVal = 0;
            if(riter->WriteLock.compare_exchange_weak(oldVal,newVal)||riter->WriteLock.load()==TID){
                it->second.emplace_back(v);
                // 释放老版本的写锁
                for(auto rriter = ++(it->second.rbegin());rriter!=it->second.rend();rriter++){
                    if(rriter->WriteLock.load()==TID){
                        rriter->WriteLock.store(0);
                        break;
                    }
                }
                return true;
            }
            // 回滚InMap的写锁修改
            auto tpIter = InEdges.find(dstID)->second;
            for(auto ttpIter = ++(tpIter.rbegin());ttpIter!=tpIter.rend();ttpIter++){
                if(ttpIter->WriteLock.load()==TID){
                    ttpIter->WriteLock.store(0);
                    break;
                }
            }
            return false;
        }
    } 
    return true;
}


void MVCCMap::ReadIndexAOF(std::string fname, std::vector<IndexAOF>& v){
    std::ifstream ifs(fname);
    while(ifs.peek()!=EOF){
        std::string tmp;
        ifs>>tmp;
        auto length = tmp.length();
        if(length==0) break;
        char op = tmp[0];
        auto rawKey = tmp.substr(1,length-1);
        ifs>>tmp;
        int64_t ver = atoi(tmp.c_str());
        if (op=='m'){
            ifs>>tmp;
            int delta = atoi(tmp.c_str());
            v.emplace_back(IndexAOF{op,rawKey,ver,delta});
        } else {
            v.emplace_back(IndexAOF{op,rawKey,ver});
        }
    }
    ifs.close();
}

void MVCCMap::ReadVEAOF(std::string fname, std::vector<VEAOF>& v){
    std::ifstream ifs(fname);
    while(ifs.peek()!=EOF){
        std::string tmp;
        ifs>>tmp;
        auto length = tmp.length();
        if(length==0) break;
        char pos = tmp[0];
        auto rawKey = tmp.substr(1,length-1);
        ifs>>tmp;
        int64_t ver = atoi(tmp.c_str());
        ifs>>tmp;   // insertEdges
        std::vector<Edge> insertEdges;
        GetEdgesFromAOF(tmp,insertEdges);
        ifs>>tmp;   // deleteEdges
        std::vector<Edge> deleteEdges;
        GetEdgesFromAOF(tmp,deleteEdges);
        v.emplace_back(VEAOF{pos,rawKey,ver,insertEdges,deleteEdges});
    }
    ifs.close();
}


void MVCCMap::GetEdgesFromAOF(std::string s,std::vector<Edge>& v){
    if(s.length()<=2) return;
    s = s.substr(1,s.length()-2)+",";
    size_t pos = s.find(",");
    while(pos!=s.npos){
        std::string tp = s.substr(0,pos);
        Edge e;
        e.FromString(tp);
        v.emplace_back(e);
        s = s.substr(pos+1, s.size());
        pos = s.find(",");
    }
    return;
}


// 重建索引
bool MVCCMap::Rebuilt(){
    std::vector<IndexAOF> v;
    std::vector<VEAOF> vv;
    ReadIndexAOF(this->IndexAOFFileName,v);
    ReadVEAOF(this->VEAOFFileName,vv);
    std::cout<<"index aof length: "<<v.size()<<"\n";
    std::cout<<"ve aof length: "<<vv.size()<<"\n";
    if(!IndexMap.empty()) IndexMap.clear();
    if(!OutEdges.empty()) OutEdges.clear();
    if(!InEdges.empty()) InEdges.clear();
    for(auto tx:v){
        auto op = tx.op;
        auto rawKey = tx.rawKey;
        auto version = tx.version;
        auto delta = tx.delta;

        auto it = IndexMap.find(rawKey);
        if(it!=IndexMap.end()){
            // 存在这个key，在链表上做修改
            if(it->second.empty()){
                // 链表空
                if(op=='m'||op=='d'){
                    continue;
                }else if(op=='a'){
                    it->second.emplace_back(IndexVersion{0,version,version});
                    continue;
                }else{
                    std::cout<<"Error! Should not reach here! Op="<<op<<"\n";
                    return false;
                }
            }
            // 链表非空，需要依次处理增删改
            if(op=='m'){
                auto iter = it->second.begin();
                while(iter!=it->second.end()){
                    if(iter->BeginTs==version) break;
                    iter++;
                }
                // 若找不到对应version，忽略
                if(iter==it->second.end()){
                    continue;
                }
                iter->ReadTs+=delta;
            }else if(op=='d'){
                // 删除整个key的所有版本
                if(version==0){
                    it->second.clear();
                    continue;
                }
                // 删除单个版本
                auto iter = it->second.begin();
                while(iter!=it->second.end()){
                    if(iter->BeginTs==version) break;
                    iter++;
                }
                if(iter==it->second.end()){
                    continue;
                }
                it->second.erase(iter);
            }else if(op=='a'){
                auto iter = it->second.begin();
                while(iter!=it->second.end()){
                    if(iter->BeginTs<version) iter++;
                    else break;
                }
                it->second.emplace(iter,IndexVersion{0,version,version});
            }else{
                std::cout<<"Error! Should not reach here! Op="<<op<<"\n";
                return false;
            }
        }else{
        // 不存在这个key，需要新建链表然后插入map
            if(op=='m'||op=='d'){
                continue;
            }else if(op=='a'){
                std::list<IndexVersion> versionList;
                versionList.emplace_back(IndexVersion{0,version,version});
                IndexMap[rawKey] = versionList;
            }else{
                std::cout<<"Error! Should not reach here! Op="<<op<<"\n";
                return false;
            }
        }
    }
    for(auto tx:vv){
        auto pos = tx.pos;
        auto rawKey = tx.vertexKey;
        auto version = tx.version;
        auto insertEdges = tx.insertEdges;
        auto deleteEdges = tx.deleteEdges;
        if(insertEdges.size()==0&&deleteEdges.size()==0) continue;  // TODO 还未实现读的修改重建
        if(pos=='0'){
            // 出边 写在OutEdges中
            auto it = OutEdges.find(rawKey);
            if(it!=OutEdges.end()){
                // version=0，删除整个key的所有版本
                if(version==0){
                    it->second.clear();
                    continue;
                }
                // 存在这个key，在链表上做修改
                if(it->second.empty()){
                    // 链表空
                    VEVersion t(0,version,version);
                    t.InsertEdges=insertEdges;
                    t.DeleteEdges=deleteEdges;
                    it->second.emplace_back(t);
                    continue;
                }
                // 链表非空   
                bool versionExist = false;
                auto iter = it->second.begin();
                while(iter!=it->second.end()){
                    if(iter->BeginTs<version) iter++;
                    else if(iter->BeginTs==version){
                        versionExist = true;
                        break;
                    }
                    else break;
                }
                // 合并相同版本
                if(versionExist){
                    if(insertEdges.size()>0) {
                        for(const auto p:insertEdges){
                            iter->InsertEdges.emplace_back(p);
                        }
                    }
                    if(deleteEdges.size()>0) {
                        for(const auto p:deleteEdges){
                            iter->DeleteEdges.emplace_back(p);
                        }
                    }
                }else{
                    VEVersion t(0,version,version);
                    t.InsertEdges=insertEdges;
                    t.DeleteEdges=deleteEdges;
                    it->second.emplace(iter,t);
                }
            }else{
            // 不存在这个key，需要新建链表然后插入map
                std::list<VEVersion> versionList;
                VEVersion t(0,version,version);
                t.InsertEdges=insertEdges;
                t.DeleteEdges=deleteEdges;
                versionList.emplace_back(t);
                OutEdges[rawKey] = versionList;
            }
        }else{
            // 入边 写在InEdges中
            auto it = InEdges.find(rawKey);
            if(it!=InEdges.end()){
                // version=0，删除整个key的所有版本
                if(version==0){
                    it->second.clear();
                    continue;
                }
                // 存在这个key，在链表上做修改
                if(it->second.empty()){
                    // 链表空
                    VEVersion t(0,version,version);
                    t.InsertEdges=insertEdges;
                    t.DeleteEdges=deleteEdges;
                    it->second.emplace_back(t);
                    continue;
                }
                // 链表非空   
                bool versionExist = false;
                auto iter = it->second.begin();
                while(iter!=it->second.end()){
                    if(iter->BeginTs<version) iter++;
                    else if(iter->BeginTs==version){
                        versionExist = true;
                        break;
                    }
                    else break;
                }
                // 合并相同版本
                if(versionExist){
                    if(insertEdges.size()>0) {
                        for(const auto p:insertEdges){
                            iter->InsertEdges.emplace_back(p);
                        }
                    }
                    if(deleteEdges.size()>0) {
                        for(const auto p:deleteEdges){
                            iter->DeleteEdges.emplace_back(p);
                        }
                    }
                }else{
                    VEVersion t(0,version,version);
                    t.InsertEdges=insertEdges;
                    t.DeleteEdges=deleteEdges;
                    it->second.emplace(iter,t);
                }
            }else{
            // 不存在这个key，需要新建链表然后插入map
                std::list<VEVersion> versionList;
                VEVersion t(0,version,version);
                t.InsertEdges=insertEdges;
                t.DeleteEdges=deleteEdges;
                versionList.emplace_back(t);
                InEdges[rawKey] = versionList;
            }
        }
    }
    return true;
}


bool MVCCMap::RebuiltWithAppend(){
    std::vector<IndexAOF> v;
    std::vector<VEAOF> vv;
    auto tpFileName1 = this->IndexAOFFileName+"_tp";
    auto tpFileName2 = this->VEAOFFileName+"_tp";
    ReadIndexAOF(tpFileName1,v);
    ReadVEAOF(tpFileName2,vv);
    for(auto tx:v){
        auto op = tx.op;
        auto rawKey = tx.rawKey;
        auto version = tx.version;
        auto delta = tx.delta;

        auto it = IndexMap.find(rawKey);
        if(it!=IndexMap.end()){
            // 存在这个key，在链表上做修改
            if(it->second.empty()){
                // 链表空
                if(op=='m'||op=='d'){
                    continue;
                }else if(op=='a'){
                    it->second.emplace_back(IndexVersion{0,version,version});
                    continue;
                }else{
                    std::cout<<"Error! Should not reach here! Op="<<op<<"\n";
                    return false;
                }
            }
            // 链表非空，需要依次处理增删改
            if(op=='m'){
                auto iter = it->second.begin();
                while(iter!=it->second.end()){
                    if(iter->BeginTs==version) break;
                    iter++;
                }
                // 若找不到对应version，忽略
                if(iter==it->second.end()){
                    continue;
                }
                iter->ReadTs+=delta;
            }else if(op=='d'){
                // 删除整个key的所有版本
                if(version==0){
                    it->second.clear();
                    continue;
                }
                // 删除单个版本
                auto iter = it->second.begin();
                while(iter!=it->second.end()){
                    if(iter->BeginTs==version) break;
                    iter++;
                }
                if(iter==it->second.end()){
                    continue;
                }
                it->second.erase(iter);
            }else if(op=='a'){
                auto iter = it->second.begin();
                while(iter!=it->second.end()){
                    if(iter->BeginTs<version) iter++;
                    else break;
                }
                it->second.emplace(iter,IndexVersion{0,version,version});
            }else{
                std::cout<<"Error! Should not reach here! Op="<<op<<"\n";
                return false;
            }
        }else{
        // 不存在这个key，需要新建链表然后插入map
            if(op=='m'||op=='d'){
                continue;
            }else if(op=='a'){
                std::list<IndexVersion> versionList;
                versionList.emplace_back(IndexVersion{0,version,version});
                IndexMap[rawKey] = versionList;
            }else{
                std::cout<<"Error! Should not reach here! Op="<<op<<"\n";
                return false;
            }
        }
    }
    for(auto tx:vv){
        auto pos = tx.pos;
        auto rawKey = tx.vertexKey;
        auto version = tx.version;
        auto insertEdges = tx.insertEdges;
        auto deleteEdges = tx.deleteEdges;
        if(pos=='0'){
            // 出边 写在OutEdges中
            auto it = OutEdges.find(rawKey);
            if(it!=OutEdges.end()){
                // version=0，删除整个key的所有版本
                if(version==0){
                    it->second.clear();
                    continue;
                }
                // 存在这个key，在链表上做修改
                if(it->second.empty()){
                    // 链表空
                    VEVersion t(0,version,version);
                    t.InsertEdges=insertEdges;
                    t.DeleteEdges=deleteEdges;
                    it->second.emplace_back(t);
                    continue;
                }
                // 链表非空   
                bool versionExist = false;
                auto iter = it->second.begin();
                while(iter!=it->second.end()){
                    if(iter->BeginTs<version) iter++;
                    else if(iter->BeginTs==version){
                        versionExist = true;
                        break;
                    }
                    else break;
                }
                // 合并相同版本
                if(versionExist){
                    if(insertEdges.size()>0) {
                        for(const auto p:insertEdges){
                            iter->InsertEdges.emplace_back(p);
                        }
                    }
                    if(deleteEdges.size()>0) {
                        for(const auto p:deleteEdges){
                            iter->DeleteEdges.emplace_back(p);
                        }
                    }
                }else{
                    VEVersion t(0,version,version);
                    t.InsertEdges=insertEdges;
                    t.DeleteEdges=deleteEdges;
                    it->second.emplace(iter,t);
                }
            }else{
            // 不存在这个key，需要新建链表然后插入map
                std::list<VEVersion> versionList;
                VEVersion t(0,version,version);
                t.InsertEdges=insertEdges;
                t.DeleteEdges=deleteEdges;
                versionList.emplace_back(t);
                OutEdges[rawKey] = versionList;
            }
        }else{
            // 入边 写在InEdges中
            auto it = InEdges.find(rawKey);
            if(it!=InEdges.end()){
                // version=0，删除整个key的所有版本
                if(version==0){
                    it->second.clear();
                    continue;
                }
                // 存在这个key，在链表上做修改
                if(it->second.empty()){
                    // 链表空
                    VEVersion t(0,version,version);
                    t.InsertEdges=insertEdges;
                    t.DeleteEdges=deleteEdges;
                    it->second.emplace_back(t);
                    continue;
                }
                // 链表非空   
                bool versionExist = false;
                auto iter = it->second.begin();
                while(iter!=it->second.end()){
                    if(iter->BeginTs<version) iter++;
                    else if(iter->BeginTs==version){
                        versionExist = true;
                        break;
                    }
                    else break;
                }
                // 合并相同版本
                if(versionExist){
                    if(insertEdges.size()>0) {
                        for(const auto p:insertEdges){
                            iter->InsertEdges.emplace_back(p);
                        }
                    }
                    if(deleteEdges.size()>0) {
                        for(const auto p:deleteEdges){
                            iter->DeleteEdges.emplace_back(p);
                        }
                    }
                }else{
                    VEVersion t(0,version,version);
                    t.InsertEdges=insertEdges;
                    t.DeleteEdges=deleteEdges;
                    it->second.emplace(iter,t);
                }
            }else{
            // 不存在这个key，需要新建链表然后插入map
                std::list<VEVersion> versionList;
                VEVersion t(0,version,version);
                t.InsertEdges=insertEdges;
                t.DeleteEdges=deleteEdges;
                versionList.emplace_back(t);
                InEdges[rawKey] = versionList;
            }
        }
    }
    return true;
}

// 读取VEMap获取边集合
GetEdgesResp MVCCMap::ReadVEMap(int64_t TID, std::string key, char pos){
    GetEdgesResp resp;
    resp.success = false;
    auto VEMap = new std::unordered_map<std::string,std::list<VEVersion>>;
    if(pos=='0'){
        VEMap = &OutEdges;
    }else{
        VEMap = &InEdges;
    }
    auto it = VEMap->find(key);
    if(it==VEMap->end()){
        return resp;
    }
    std::vector<Edge> edges;
    std::unordered_set<std::string> edgeSet;
    int64_t delta = 0;
    auto iter = it->second.begin();
    for(;iter!=it->second.end();iter++){
        #if IsolationLevel==1 // RC
        // 找到最后一个可以读的公开版本
        if(iter->WriteLock.load()==TID||iter->WriteLock.load()==0){
            auto insertEdges = iter->InsertEdges;
            auto deleteEdges = iter->DeleteEdges;
            for(const auto e:insertEdges){
                edgeSet.emplace(e.ToOutString());
            }            
            for(const auto e:deleteEdges){
                edgeSet.erase(e.ToOutString());
            }
            if(iter->ReadTs<TID){  // 更新readTs为TID
                delta = TID-iter->ReadTs;
                iter->ReadTs = TID;
            }
        }
        else break;
        #elif IsolationLevel==2 // RR
        // 找到最后一个可以读的早于自己的版本
        if(iter->BeginTs<=TID&&(iter->WriteLock.load()==TID||iter->WriteLock.load()==0)){
            auto insertEdges = iter->InsertEdges;
            auto deleteEdges = iter->DeleteEdges;
            for(const auto e:insertEdges){
                edgeSet.emplace(e.ToOutString());
            }            
            for(const auto e:deleteEdges){
                edgeSet.erase(e.ToOutString());
            }
            if(iter->ReadTs<TID){  // 更新readTs为TID
                delta = TID-iter->ReadTs;
                iter->ReadTs = TID;
            }
        }
        else break;
        #else // Serializable
        #endif
    }
    for(const auto it:edgeSet){
        Edge e;
        e.FromString(it);
        edges.emplace_back(e);
    }
    resp.success = true;
    resp.edges = edges;
    resp.delta = delta;
    return resp;
}