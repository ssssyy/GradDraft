#include "rocksdbapi.h"

std::string RocksDBAPI::Get(std::string key){
    Slice nkey(key);
    std::string val;
    status = db->Get(ro,nkey,&val);
    if(status.ok()){
        return val;
    }else if(status.IsNotFound()){
        return "";
    }else{
        throw "get error";
    }
    return "";
}

std::vector<std::string> RocksDBAPI::MultiGet(std::vector<std::string> keys){
    std::vector<Slice> nkeys;
    for(auto key:keys){
        Slice nkey(key);
        nkeys.push_back(nkey);
    }
    std::vector<std::string> vals;
    auto res = db->MultiGet(ro,nkeys,&vals);
    return vals;
}

void RocksDBAPI::Put(std::string key, std::string val){
    Slice nkey(key);
    Slice nval(val);
    status = db->Put(wo,nkey,nval);
    if(!status.ok()){
        throw "put error";
    }
}

void RocksDBAPI::MultiPut(std::vector<std::string> keys, std::vector<std::string> vals){
    if(keys.size()!=vals.size()){
        throw "multi put error, keys and vals size not equal";
    }
    std::vector<Slice> nkeys;
    std::vector<Slice> nvals;
    for(const auto &key:keys){
        Slice nkey(key);
        nkeys.push_back(nkey);
    }
    for(const auto &val:vals){
        Slice nval(val);
        nvals.push_back(nval);
    }
    for(auto x=std::begin(nkeys),y=std::begin(nvals);x!=std::end(nkeys),y!=std::end(nvals);x++,y++){
        status = db->Put(wo,*x,*y);
        if(!status.ok()){
            throw "multi put error";
        }
    }
}

void RocksDBAPI::Delete(std::string key){
    Slice nkey(key);
    status = db->Delete(wo,nkey);
    if(!status.ok()){
        throw "delete error";
    }
}

void RocksDBAPI::MultiDelete(std::vector<std::string> keys){
    std::vector<Slice> nkeys;
    for(auto key:keys){
        Slice nkey(key);
        nkeys.push_back(nkey);
    }
    for(auto x=std::begin(nkeys);x!=std::end(nkeys);x++){
        status = db->Delete(wo,*x);
        if(!status.ok()){
            throw "multi delete error";
        }
    }
}

