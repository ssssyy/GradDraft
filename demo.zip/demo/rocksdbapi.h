#include <string>
#include <vector>
#include <rocksdb/db.h>
#include <rocksdb/slice.h>
#include <rocksdb/options.h>
using namespace rocksdb;



class RocksDBAPI{
private:
    DB *db;
    Status status;
    const std::string PATH = "/tmp/rocksdbResult";
    WriteOptions wo;
    ReadOptions ro;
public:
    RocksDBAPI(){
        Options options;
        options.create_if_missing = true;
        Status status = DB::Open(options,PATH,&db);
        if(!status.ok()){
            throw "init db failed";
        }
        wo = WriteOptions();
        wo.sync = true;
        ro = ReadOptions();
    }
    ~RocksDBAPI(){
        delete db;
    }
    std::string Get(std::string);
    void Put(std::string,std::string);
    void Delete(std::string);
    std::vector<std::string> MultiGet(std::vector<std::string>);
    void MultiDelete(std::vector<std::string>);
    void MultiPut(std::vector<std::string>,std::vector<std::string>);
};