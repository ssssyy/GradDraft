#include<cstdint>
#include<unistd.h>
#include<unordered_map>
#include<string>
#include<vector>
#include<set>
#include<sstream>
#include<cstdlib>
#include<algorithm>
#include<fstream>
#include<memory>
#include<iostream>
#include<bitset>
#include<pthread.h>
#include<list>
#include<atomic>
#include "concurrentqueue.h"
#include "rocksdbapi.h"

extern std::vector<std::string> split(const std::string&,const std::string&);

struct Edge{
    std::string EdgeID;
    std::string EdgeType;
    std::string srcID;
    std::string dstID;
    int8_t pos; // 0为出边 1为入边
    Edge(){}
    // need modify to use in true system
    std::string GetSrcID()const{return srcID;}
    std::string GetDstID()const{return dstID;}
    int8_t GetPos()const{return pos;}
    std::string GetEdgeType()const{return EdgeType;}
    std::string ToOutString()const{
        return EdgeID+"+"+EdgeType+"+"+srcID+"+"+dstID+"+"+"0";
    }
    std::string ToInString()const{
        return EdgeID+"+"+EdgeType+"+"+dstID+"+"+srcID+"+"+"1";
    }
    void FromString(std::string EdgeStr){   // edge str使用加号分割
        auto res = split(EdgeStr,"+");
        this->EdgeID = res[0];
        this->EdgeType = res[1];
        this->srcID = res[2];
        this->dstID = res[3];
        this->pos = atoi(res[4].c_str());
        if(this->pos==1) std::swap(this->srcID,this->dstID);
    }
};


struct EdgeKeyHash{
    std::size_t operator()(const Edge& e) const{
        return std::hash<std::string>()(e.EdgeID);
    }
};

struct EdgeKeyEqual{
    bool operator() (const Edge &e1, const Edge &e2) const{
        return e1.EdgeID==e1.EdgeID;
    }
};

struct IndexAOF{
    char op;
    std::string rawKey;
    int64_t version;
    int64_t delta;
};

// VEAOF不需要表明操作类型 version=0表示删除
// 若insert和delete都为空，此时是读操作的AOF，version表示readTs变更
struct VEAOF{ 
    char pos;   // 0为出边 1为入边
    std::string vertexKey;
    int64_t version;
    std::vector<Edge> insertEdges;
    std::vector<Edge> deleteEdges;
};

struct IndexVersion{
    std::atomic<int64_t> WriteLock;
    int64_t ReadTs;
    int64_t BeginTs;
    IndexVersion():ReadTs(0),BeginTs(0){WriteLock.store(0);}
    IndexVersion(int64_t wl,int64_t rt,int64_t ts):ReadTs(rt),BeginTs(ts){WriteLock.store(wl);}
    IndexVersion(const IndexVersion& v){
        WriteLock.store(v.WriteLock.load());
        ReadTs = v.ReadTs;
        BeginTs = v.BeginTs;
    }
    IndexVersion& operator=(const IndexVersion& v){
        WriteLock.store(v.WriteLock.load());
        ReadTs = v.ReadTs;
        BeginTs = v.BeginTs;
        return *this;
    }
};

struct VEVersion: public IndexVersion{
    std::vector<Edge> InsertEdges;
    std::vector<Edge> DeleteEdges;
    VEVersion(){IndexVersion();}
    VEVersion(int64_t wl,int64_t rt,int64_t ts){
        WriteLock.store(wl);
        ReadTs = rt;
        BeginTs = ts;
    }
    VEVersion(const VEVersion& v){
        WriteLock.store(v.WriteLock.load());
        ReadTs = v.ReadTs;
        BeginTs = v.BeginTs;
        InsertEdges = v.InsertEdges;
        DeleteEdges = v.DeleteEdges;
    }
    VEVersion& operator=(const VEVersion& v){
        WriteLock.store(v.WriteLock.load());
        ReadTs = v.ReadTs;
        BeginTs = v.BeginTs;
        InsertEdges = v.InsertEdges;
        DeleteEdges = v.DeleteEdges;
        return *this;
    }
};

struct ReadResp{
    int64_t beginTs;
    int64_t deltaTs;
    bool success;
    bool exist;
};

struct WriteResp{
    bool success;
    bool needRCU;
};

struct GetEdgesResp{
    bool success;
    int64_t delta;
    std::vector<Edge> edges;
};

class TransactionManager;

class MVCCMap{
private:
    std::string IndexAOFFileName;
    std::string VEAOFFileName;

public:
    std::unordered_map<std::string, std::atomic<int64_t> > LatestVersion;
    std::unordered_map<std::string, std::list<IndexVersion> > IndexMap;
    std::unordered_map<std::string, std::list<VEVersion> > OutEdges;
    std::unordered_map<std::string, std::list<VEVersion> > InEdges;
    MVCCMap(){
        IndexAOFFileName = "./aof";
        VEAOFFileName = "./veaof";
    }
    ~MVCCMap(){
        for(auto e:IndexMap){
            e.second.clear();
        }
        IndexMap.clear();
        for(auto e:InEdges){
            e.second.clear();
        }
        InEdges.clear();
        for(auto e:OutEdges){
            e.second.clear();
        }
        OutEdges.clear();
        LatestVersion.clear();
    }    

    ReadResp ReadIndex(int64_t,std::string);    // 读取操作
    WriteResp CreateIndex(int64_t,std::string); // 创建操作
    WriteResp UpdateIndex(int64_t,std::string); // 更新操作
    WriteResp DeleteIndex(int64_t,std::string); // 删除操作

    bool Rebuilt();                              // 重建map
    bool RebuiltWithAppend();                    // 将临时AOF文件追加到map上
    bool WriteVE(int64_t,Edge,char);       // Insert/Delete Edge时写VE Map
    void ReadIndexAOF(std::string,std::vector<IndexAOF>&);      // 读IndexAOF
    void ReadVEAOF(std::string,std::vector<VEAOF>&);            // 读VEAOF
    void GetEdgesFromAOF(std::string,std::vector<Edge>&);  // 辅助读VEAOF获取边集
    GetEdgesResp ReadVEMap(int64_t,std::string,char); // 从VE Map读取边集
};



/****************************************************************
 *****************以下是TransactionManager************************
 ****************************************************************/


class RWITem{
public:
    int64_t version;
};

class WItem: public RWITem{
public:
    char operation;
};

class RItem: public RWITem{
public:
    int64_t deltaTs;
};

struct Transaction{
    int64_t TID;
    std::unordered_map<std::string,std::vector<RItem> > ReadSet;
    std::unordered_map<std::string,std::vector<WItem> > WriteSet;
    std::unordered_map<std::string,WItem> UndoWriteSet; // undoWriteSet每个key每个事务只有一个最终版本
    std::vector<Edge> EdgeIndexes;
    std::bitset<1024> InsertEdges;
    std::bitset<1024> DeleteEdges; 

    Transaction():TID(0){};
    Transaction(int64_t tid):TID(tid){};
};

struct TXStatus{
    int64_t TID;
    bool Deleted;
    bool operator ==(const TXStatus &t){
        return (this->TID==t.TID)&&(this->Deleted==t.Deleted);
    }
};


class TransactionManager{
private:
    class MVCCMap GlobalMap;
    std::unordered_map<int64_t,Transaction*> TXs;
    std::unordered_map<std::string,std::vector<TXStatus> > ReadSets;
    std::set<int64_t> ActiveTX;
    std::string IndexAOFFileName;
    std::string VEAOFFileName;
    RocksDBAPI rocksdbapi;
    pthread_rwlock_t rwLock;
    std::atomic<bool> reWriteFlag;

public:
    TransactionManager(){
        IndexAOFBuffer = new moodycamel::ConcurrentQueue<IndexAOF>(128);
        VEAOFBuffer = new moodycamel::ConcurrentQueue<VEAOF>(128);
        IndexAOFFileName = "./aof";
        VEAOFFileName = "./veaof";
        pthread_rwlock_init(&rwLock,NULL);
        reWriteFlag.store(false);
    }
    ~TransactionManager(){
        pthread_rwlock_destroy(&rwLock);
        delete IndexAOFBuffer;
        delete VEAOFBuffer;
        for(auto it:TXs){
            delete(it.second);
        }
        for(auto x:ReadSets){
            x.second.clear();
        }
        TXs.clear();
        ReadSets.clear();
        ActiveTX.clear();
    }
    bool Register(int64_t); // 注册事务 
    bool Commit(int64_t);   // 提交事务
    bool Abort(int64_t);    // 回滚事务
    int64_t GetMinTX();     // 获取最小活跃事务ID
    int64_t GetMaxTX();     // 获取最大活跃事务ID

public:     // CRUD API
    std::string Read(int64_t,std::string);            
    bool Create(int64_t,std::string,std::string,bool);   
    bool Update(int64_t,std::string,std::string);
    bool Delete(int64_t,std::string,bool);     
    std::vector<std::string> GetNeighbors(int64_t,std::string,std::unordered_set<std::string>,int);    // 获取一个顶点的所有指定边类型要求的一步邻居
            // CRUD辅助函数
    bool CreateIndexMap(int64_t,std::string,std::string);
    bool DeleteIndexMap(int64_t,std::string);
    ReadResp CheckIfNotExist(int64_t,std::string);

public:    // These are used for debugging
    void PrintTX();
    void PrintReadSets();
    void PrintActiveTX();
    void PrintIndexMap();
    void PrintVEMap();

public: 
    int GetReadLock();      // 所有事务访问时都获取读锁
    int GetWriteLock();     // GC访问和重写时获取写锁
    int Unlock();       

    void GC();              // GC

//AOF Manager
private:
    moodycamel::ConcurrentQueue<IndexAOF>* IndexAOFBuffer;
    moodycamel::ConcurrentQueue<VEAOF>* VEAOFBuffer;

public:
    bool WriteIndexAOF(std::vector<IndexAOF>);  // IndexAOF写入
    bool WriteVEAOF(std::vector<VEAOF>);        // VEAOF写入
    void IndexAOFEncode(IndexAOF,std::string&); // IndexAOF编码
    void VEAOFEncode(VEAOF,std::string&);       // VEAOF编码
    bool RollbackReadItem(std::string,int64_t,int64_t,int64_t); // 回滚IndexMap的读操作
    bool RollbackAddItem(std::string,int64_t);          // 回滚IndexMap的版本添加操作
    bool RollbackDeleteItem(std::string,int64_t);       // 回滚IndexMap的版本删除操作
    bool RollbackVEItem(std::string,int64_t);           // 回滚VEMap的版本添加操作


    void RewriteAOF();                              // 重写AOF文件
    void Rebuilt();                                 // 恢复内存索引

    bool IsVertex(std::string);                     // 辅助方法，判定一个key是否是vertex

};




